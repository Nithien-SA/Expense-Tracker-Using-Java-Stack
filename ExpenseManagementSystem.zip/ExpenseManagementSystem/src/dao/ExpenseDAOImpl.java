package dao;

import model.Expense;
import model.ExpenseType;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import utility.DBConnection;

public class ExpenseDAOImpl implements ExpenseDAO 
{

    @Override
    public void addExpense(Expense expense) throws Exception 
    {
        String query = "INSERT INTO Expenses (vehicle_id, type, amount, date, description) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) 
        {
            ps.setInt(1, expense.getVehicleId());
            ps.setString(2, expense.getType().name());
            ps.setDouble(3, expense.getAmount());
            ps.setDate(4, new java.sql.Date(expense.getDate().getTime()));
            ps.setString(5, expense.getDescription());
            ps.executeUpdate();
        }
    }

    @Override
    public List<Expense> getExpensesByVehicleId(int vehicleId) 
    {
        List<Expense> expenses = new ArrayList<>();
        String query = "SELECT * FROM Expenses WHERE vehicle_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) 
        {
            ps.setInt(1, vehicleId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Expense expense = new Expense(
                        rs.getInt("expense_id"),
                        rs.getInt("vehicle_id"),
                        ExpenseType.valueOf(rs.getString("type")),
                        rs.getDouble("amount"),
                        rs.getDate("date"),
                        rs.getString("description")
                );
                expenses.add(expense);
            }
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
        return expenses;
    }

    @Override
    public double getTotalExpenses() 
    {
        double totalExpenses = 0;
        String query = "SELECT SUM(amount) AS total_expenses FROM Expenses";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) 
        {
            ResultSet rs = ps.executeQuery();
            if (rs.next()) 
            {
                totalExpenses = rs.getDouble("total_expenses");
            }
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
        return totalExpenses;
    }

    @Override
    public List<Expense> getExpensesByType(ExpenseType type) 
    {
        List<Expense> expenses = new ArrayList<>();
        String query = "SELECT * FROM Expenses WHERE type = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) 
        {
            ps.setString(1, type.name());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) 
            {
                Expense expense = new Expense(
                        rs.getInt("expense_id"),
                        rs.getInt("vehicle_id"),
                        ExpenseType.valueOf(rs.getString("type")),
                        rs.getDouble("amount"),
                        rs.getDate("date"),
                        rs.getString("description")
                );
                expenses.add(expense);
            }
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
        return expenses;
    }
}

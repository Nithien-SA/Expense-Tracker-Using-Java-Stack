package model;

public enum ExpenseType 
{
    FUEL,
    MAINTENANCE,
    INSURANCE,
    REPAIR
}

package dao;

import java.util.List;
import model.Expense;
import model.ExpenseType;

public interface ExpenseDAO 
{
    void addExpense(Expense expense) throws Exception;
    List<Expense> getExpensesByVehicleId(int vehicleId);
    double getTotalExpenses();
    List<Expense> getExpensesByType(ExpenseType type);
}

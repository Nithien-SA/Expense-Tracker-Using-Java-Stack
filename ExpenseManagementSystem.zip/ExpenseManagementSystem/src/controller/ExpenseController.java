package controller;

import model.Expense;
import model.ExpenseType;
import service.ExpenseService;
import service.ExpenseServiceImpl;

public class ExpenseController 
{
    private ExpenseService expenseService = new ExpenseServiceImpl();

    public void addExpense(int vehicleId, ExpenseType type, double amount, String description) throws Exception 
    {
        Expense expense = new Expense(0, vehicleId, type, amount, new java.util.Date(), description);
        expenseService.addExpense(expense);
    }

    public String viewExpenseReport() 
    {
        return expenseService.generateExpenseReport();
    }
}

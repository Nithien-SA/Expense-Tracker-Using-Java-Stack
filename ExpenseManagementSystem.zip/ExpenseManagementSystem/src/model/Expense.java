package model;

import java.util.Date;

public class Expense 
{
    private int expenseId;
    private int vehicleId;
    private ExpenseType type;
    private double amount;
    private Date date;
    private String description;

    // Constructor
    public Expense(int expenseId, int vehicleId, ExpenseType type, double amount, Date date, String description) 
    {
        this.expenseId = expenseId;
        this.vehicleId = vehicleId;
        this.type = type;
        this.amount = amount;
        this.date = date;
        this.description = description;
    }

    // Getters and Setters
    public int getExpenseId() 
    {
		return expenseId;
	}

	public void setExpenseId(int expenseId) 
	{
		this.expenseId = expenseId;
	}

	public int getVehicleId() 
	{
		return vehicleId;
	}

	public void setVehicleId(int vehicleId) 
	{
		this.vehicleId = vehicleId;
	}

	public ExpenseType getType() 
	{
		return type;
	}

	public void setType(ExpenseType type) 
	{
		this.type = type;
	}

	public double getAmount() 
	{
		return amount;
	}

	public void setAmount(double amount) 
	{
		this.amount = amount;
	}

	public Date getDate() 
	{
		return date;
	}

	public void setDate(Date date) 
	{
		this.date = date;
	}

	public String getDescription() 
	{
		return description;
	}

	public void setDescription(String description) 
	{
		this.description = description;
	}
}

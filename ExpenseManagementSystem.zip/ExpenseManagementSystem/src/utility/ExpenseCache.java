package utility;

import model.Expense;
import java.util.LinkedHashMap;
import java.util.Map;

public class ExpenseCache 
{
    private static final int CACHE_SIZE = 50;  // Size of the cache
    private static final LinkedHashMap<Integer, Expense> expenseCache = new LinkedHashMap<Integer, Expense>(CACHE_SIZE, 0.75f, true) 
    {
        protected boolean removeEldestEntry(Map.Entry<Integer, Expense> eldest) {
            return size() > CACHE_SIZE;
        }
    };

    // Add an expense to the cache
    public static void addExpenseToCache(Expense expense) 
    {
        expenseCache.put(expense.getExpenseId(), expense);
    }

    // Retrieve an expense from the cache by ID
    public static Expense getExpenseFromCache(int expenseId) 
    {
        return expenseCache.get(expenseId);
    }

    // Clear the cache
    public static void clearCache() 
    {
        expenseCache.clear();
    }
}

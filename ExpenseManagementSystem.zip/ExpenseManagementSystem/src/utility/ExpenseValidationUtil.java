package utility;

import exception.InvalidExpenseException;
import model.Expense;
import model.ExpenseType;

public class ExpenseValidationUtil 
{

    // Validates the expense amount and type
    public static void validateExpense(Expense expense) throws InvalidExpenseException 
    {
        if (expense.getAmount() <= 0) 
        {
            throw new InvalidExpenseException("Expense amount must be positive.");
        }
        if (expense.getType() == null) 
        {
            throw new InvalidExpenseException("Expense type cannot be null.");
        }
    }

    // Validates an ExpenseType
    public static boolean isValidExpenseType(ExpenseType type) 
    {
        for (ExpenseType validType : ExpenseType.values()) 
        {
            if (validType == type) {
                return true;
            }
        }
        return false;
    }
}

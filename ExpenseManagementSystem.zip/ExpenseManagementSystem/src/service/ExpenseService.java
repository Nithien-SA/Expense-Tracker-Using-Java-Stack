package service;

import java.util.List;
import model.Expense;
import model.ExpenseType;

public interface ExpenseService 
{
    void addExpense(Expense expense) throws Exception;
    List<Expense> getVehicleExpenses(int vehicleId);
    double getTotalExpenses();
    List<Expense> getExpensesByType(ExpenseType type);
    String generateExpenseReport();
}

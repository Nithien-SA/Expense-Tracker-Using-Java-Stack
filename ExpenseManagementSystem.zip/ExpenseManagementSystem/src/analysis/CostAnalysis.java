package analysis;

import model.Expense;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.stream.Collectors;

public class CostAnalysis 
{

    // Calculate total expenses across all expense records
    public static double calculateTotalExpenses(List<Expense> expenses) 
    {
        return expenses.stream().mapToDouble(Expense::getAmount).sum();
    }

    // Calculate the average expense amount
    public static double calculateAverageExpense(List<Expense> expenses) 
    {
        return expenses.isEmpty() ? 0 : calculateTotalExpenses(expenses) / expenses.size();
    }

    // Calculate monthly expense trends by year
    public static Map<Integer, Map<Integer, Double>> calculateMonthlyTrends(List<Expense> expenses) 
    {
        return expenses.stream().collect(Collectors.groupingBy(
                expense -> expense.getDate().getYear() + 1900,
                Collectors.groupingBy(
                        expense -> expense.getDate().getMonth() + 1,
                        Collectors.summingDouble(Expense::getAmount)
                )
        ));
    }

    // Calculate total expenses per category
    public static Map<String, Double> calculateCategoryWiseExpenses(List<Expense> expenses) 
    {
        return expenses.stream().collect(Collectors.groupingBy(
                expense -> expense.getType().name(),
                Collectors.summingDouble(Expense::getAmount)
        ));
    }
}

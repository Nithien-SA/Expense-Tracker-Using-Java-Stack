package service;

import java.util.List;
import dao.ExpenseDAO;
import dao.ExpenseDAOImpl;
import model.Expense;
import model.ExpenseType;

public class ExpenseServiceImpl implements ExpenseService 
{
    private ExpenseDAO expenseDAO = new ExpenseDAOImpl();

    @Override
    public void addExpense(Expense expense) throws Exception 
    {
        if (expense.getAmount() <= 0) throw new IllegalArgumentException("Amount must be positive");
        expenseDAO.addExpense(expense);
    }

    @Override
    public List<Expense> getVehicleExpenses(int vehicleId) 
    {
        return expenseDAO.getExpensesByVehicleId(vehicleId);
    }

    @Override
    public double getTotalExpenses() 
    {
        return expenseDAO.getTotalExpenses();
    }

    @Override
    public List<Expense> getExpensesByType(ExpenseType type) 
    {
        return expenseDAO.getExpensesByType(type);
    }

    @Override
    public String generateExpenseReport() 
    {
        StringBuilder report = new StringBuilder("Expense Report:\n");
        report.append("Total Expenses: ").append(getTotalExpenses()).append("\n");

        for (ExpenseType type : ExpenseType.values()) 
        {
            report.append(type.name()).append(" Expenses: ");
            double typeTotal = expenseDAO.getExpensesByType(type).stream().mapToDouble(Expense::getAmount).sum();
            report.append(typeTotal).append("\n");
        }

        return report.toString();
    }
}
